import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Mail, Phone, FileText, Award, BookOpen, 
  Users, Heart, Code, Globe, ChevronRight,
  ExternalLink, MapPin, Calendar, GraduationCap, Folder, Stethoscope, User, Wand2, Send
} from 'lucide-react';
import UserProfile from './components/UserProfile';
import AvatarCreator from './components/AvatarCreator';

const EXPERIENCE = [
  {
    title: "Medical Intern",
    institution: "Hospital Nacional Alberto Sabogal Sologuren (ESSALUD)",
    location: "Callao, Lima, PE",
    date: "Present",
    description: "Working and studying as a medical intern in one of the main hospitals of the ESSALUD network."
  }
];

const AWARDS = [
  {
    title: "III PAMS Research Competition",
    date: "September 2023",
    description: "Co-author winner of 1st place in the category of Health Research in the Andean Regions or the Peruvian Amazon for the work entitled \"Depression in Quechua-speaking older adults living in 5 communities located at high altitude in the Ayacucho region - Peru during the year 2023\""
  },
  {
    title: "XXVII Regional Scientific Conference Center (JCRC), Huancayo, PE",
    date: "March 2024",
    description: "Lead author and presenter, winner of 2nd place in the Research Paper category, for the work entitled “Association of the C-Reactive Protein/Albumin ratio with poor prognosis in patients diagnosed with aneurysmal subarachnoid hemorrhage: a systematic review”"
  },
  {
    title: "Call for exchange 2024, San Fernando Faculty of Medicine",
    date: "March 2024",
    description: "1st Place, exchange recipient to the University of Rochester, Rochester, New York, USA 2025"
  },
  {
    title: "XXXVIII SOCIMEP National Scientific Congress, Tacna, PE",
    date: "August 2024",
    description: "Co-author winner of 1st place in the Research Work category for the work entitled “Health-related quality of life in adults of the native community of San Francisco and rural communities of Yarinacocha in the Ucayali region-Peru during the year 2023”"
  }
];

const POSTERS = [
  {
    event: "10th Congress on Academic Integrity. Monterrey, Mexico",
    date: "September 2022",
    details: "Meneses G, Lapeyre -Rivera A, Luna-Peralta G, Ortega-Guillén E. Translation and cultural adaptation of the McCabe Academic Integrity questionnaire in students."
  },
  {
    event: "CIS 2023 Annual Meeting: Immune Deficiency and Dysregulation North American Conference. St. Louis, Missouri, USA",
    date: "May 2023",
    details: "Toribio-Dionicio C, Veramendi -Espinoza L, Luna-Peralta G, Gavino-Alarcón F, Jara-Rodas C, Cordova-Calderón W, Aldave JC. Clinical features and treatment of activated PI3K-delta syndrome in Peruvian children: A case series."
  },
  {
    event: "American Academy of Neurology's Annual Meeting. Denver, Colorado, USA",
    date: "April 2024",
    details: "Luna-Peralta G, Lopez-Luza C, Cruzalegui -Bazan C, Cabanillas-Lazo M. “Association of the C-reactive Protein/Albumin Ratio with the Prognosis of Aneurysmal Subarachnoid Hemorrhage: A Systematic Review.”"
  },
  {
    event: "American Academy of Neurology's Summer Conference. Atlanta, Georgia, USA",
    date: "July 2024",
    details: [
      "Luna-Peralta G, Quispe-Vicuña C, Capcha -Jimenez U, Baltazar- Ñahui H, Montes-Baldarrago A, Mora-Arévalo J, Velazco-Muñoz J. Anti-Yo positive Paraneoplastic Cerebellar Degeneration: A Systematic Review of Cases.",
      "Quispe-Vicuña C, Luna-Peralta G, Capcha -Jimenez U, Lopez-Luza A, Montes-Baldarrago A. Association between body mass index (BMI) and Guillain-Barr Syndrome: A systematic review with meta-analysis.",
      "Lopez-Luza A, Luna-Peralta G, Mantilla - Chachico G, Velazco-Muñoz J, Uriol -Alvino S, Cabanillas-Lazo M. Association between Body Mass Index (BMI) and Neuromyelitis Optica Spectrum Disorder (NMOSD): A systematic review with meta-analysis.",
      "Acurio K, Luna-Peralta G, Chinchihualpa N, Cruzalegui C, Mantilla -Chachico G, Pacheco N, Quispe C. Efficacy of Intravenous Immunoglobulins for the axonal variants of Guillain-Barr syndrome: A systematic review and meta-analysis.",
      "Castañeda-Perez M, Arquiñigo-Tixe L, Luna-Peralta G, Lapeyre-Rivera André, Carbajal-García G, Cabanillas-Lazo M. The neutrophil-to-lymphocyte ratio as a prognostic biomarker in Autoimmune Encephalitis: A systematic review and meta-analysis.",
      "Castro-Suárez P, Cruzalegui -Bazán C, Luna-Peralta G, Moreno-Marquina D, Quispe-Vicuña C, Cabanillas-Lazo M. Surgery history as a risk factor for the development and prognosis of Guillain-Barré Syndrome: A systematic review and meta analysis."
    ]
  }
];

const PUBLICATIONS = [
  {
    type: "Papers",
    items: [
      {
        text: "Luna-Peralta G, López-Luza A, Cruzalegui -Bazán C, Cabanillas-Lazo M. Association of the C-reactive protein/albumin ratio with the prognosis of Aneurysmal Subarachnoid Hemorrhage: A systematic review. Neurosurgery (Astur: Engl Ed). 2024 Nov 20:S 2529-8496(24)00075-3. doi: 10.1016/j.neucie.2024.11.009."
      }
    ]
  },
  {
    type: "Video",
    items: [
      {
        text: "Clinical Problem Solvers Virtual Morning Report. 1-hour session, international audience of ~50. Role: Case presenter.",
        link: "https://clinicalproblemsolving.com/virtual-morning-report-august-17-2023-2/",
        date: "August 17, 2023"
      },
      {
        text: "Clinical Problem Solvers Virtual Morning Report. 1-hour session, international audience of ~50. Role: Discussant.",
        link: "https://clinicalproblemsolving.com/virtual-morning-report-october-19-2023/",
        date: "October 19, 2023"
      },
      {
        text: "Clinical Problem Solvers Neurology Virtual Morning Report. 1-hour session, international audience of ~50. Role: Discussant.",
        link: "https://clinicalproblemsolving.com/neurology-virtual-morning-report-january-23-2024/",
        date: "January 23, 2024"
      },
      {
        text: "Clinical Problem Solvers Neurology Virtual Morning Report. 1-hour session, international audience of ~50. Role: Discussant.",
        link: "https://clinicalproblemsolving.com/neurology-virtual-morning-report-april-6-2024/",
        date: "April 6, 2024"
      },
      {
        text: "Clinical Problem Solvers Neurology Virtual Morning Report. 1-hour session, international audience of ~50. Role: Discussant.",
        link: "https://clinicalproblemsolving.com/virtual-morning-report-january-23-2025/",
        date: "January 23, 2025"
      }
    ]
  },
  {
    type: "Blogs & Essays",
    items: [
      {
        text: "La teoría del todo: el eterno presente, dealing with uncertainty, like Schrödinger’s cat.",
        description: "A philosophical reflection on navigating life, uncertainty, and finding meaning as a self-raised atheist.",
        date: "Upcoming"
      },
      {
        text: "The Importance of Free Education In Medicine: My Story. Neurology Journals.",
        link: "https://www.neurology.org/media/blog-post/importance-free-education-medicine-my-story",
        date: "August 2024"
      }
    ]
  },
  {
    type: "Learning tools",
    items: [
      {
        text: "Head of the Neuro-Oncology chapter at Neuranki: the first ever anki deck for neurology residents.",
        link: "https://www.theneurotransmitters.com/neuranki",
        date: "November 2023"
      },
      {
        text: "Physical Examination in Neurology, 1st Edition. Open access.",
        link: "https://drive.google.com/file/d/1qPDJ--kuUB0w6aL2I97gqsRCwck01zYz/view",
        date: "May 2024"
      }
    ]
  }
];

const PROJECTS = [
  {
    title: "Physical Examination in Neurology, 1st Edition",
    description: "An open access resource for medical students to learn basic neurologic semiology for a general doctor. Currently working on the 2nd Edition.",
    link: "https://drive.google.com/file/d/1qPDJ--kuUB0w6aL2I97gqsRCwck01zYz/view",
    linkText: "View Manual"
  },
  {
    title: "Neuranki: Neuro-Oncology Chapter",
    description: "Head of the Neuro-Oncology chapter at Neuranki, the first ever Anki deck designed specifically for neurology residents.",
    link: "https://www.theneurotransmitters.com/neuranki",
    linkText: "View Project"
  },
  {
    title: "Creative Explorations: TikTok Content",
    description: "A creative outlet exploring complex ideas. Fun fact: ChatGPT estimated my IQ at 157, and this particular video was conceptualized during a highly elevated, creative state of mind.",
    link: "https://www.tiktok.com/@gerarlunap/video/7388447981319621893",
    linkText: "Watch on TikTok"
  }
];

const LEADERSHIP = [
  {
    organization: "Scientific Society of San Fernando (SCSF)",
    roles: [
      { title: "Past-President", date: "2025" },
      { title: "Director of the Research Line in Neurology and Neurosurgery", date: "2024" },
      { title: "Secretary of the Board of Directors", date: "2023" },
      { title: "Research Coordinator at the Permanent Academic Committee (CPA)", date: "2022" }
    ]
  },
  {
    organization: "Assistantship in Pathophysiology and Semiology (AsFyS)",
    roles: [
      { title: "Teacher Assistant", date: "July 2022 - present" },
      { title: "Academic Coordinator", date: "2023-2024" }
    ]
  },
  {
    organization: "Student Interest Group in Neurology (SIGN)",
    roles: [
      { title: "Founder and President", date: "May 2024 – present" }
    ]
  },
  {
    organization: "Neuroscience Interest Club (NIC)",
    roles: [
      { title: "Co-Founder and President", date: "January 2023 - present" }
    ]
  }
];

const VOLUNTEERING = [
  {
    role: "Research team, Multidisciplinary University Research and Service Camp (CUMIS)",
    location: "town of Muñapucro, Apurímac, PE",
    date: "December 2024"
  },
  {
    role: "Research team, Multidisciplinary University Research and Service Camp (CUMIS)",
    location: "Native Community of San Francisco, Pucallpa, PE",
    date: "December 2023"
  },
  {
    role: "Research team, Multidisciplinary University Research and Service Camp (CUMIS)",
    location: "town of Catalinayocc, Ayacucho, PE",
    date: "March 2023"
  },
  {
    role: "Assistant to the Multidisciplinary University Research and Service Camp (CUMIS)",
    location: "town of Tantacoto, Huánuco, PE",
    date: "April 2022"
  }
];

const COURSES = [
  { title: "Responsible Conduct in Research Course, Andean Center for Research and Training in Informatics for Global Health", date: "2021" },
  { title: "Research Methodology Course, Peruvian Medical Student Scientific Society (SOCIMEP)", date: "2021" },
  { title: "Training and Resources in Research Ethics Evaluation (TRREE) Course", date: "2022" },
  { title: "Injectables and First Aid Course (CIPA)", date: "2022" }
];

const SKILLS = [
  { category: "Statistical analysis software", items: "EpiInfo (basic), R studio" },
  { category: "Reference managers", items: "Mendeley, Zotero" },
  { category: "Survey Software and Tools", items: "Surveymonkey and Google Forms" },
  { category: "Design programs", items: "Canva" },
  { category: "Microsoft Office", items: "Advanced" }
];

const LANGUAGES = [
  { language: "Spanish", proficiency: "Native" },
  { language: "English", proficiency: "Advanced (TOEFL: 101, Duolingo: 135)" }
];

const SectionHeading = ({ children, icon: Icon }: { children: React.ReactNode, icon: React.ElementType }) => (
  <div className="flex items-center gap-3 mb-8 border-b border-slate-200 pb-4">
    <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
      <Icon size={24} />
    </div>
    <h2 className="text-2xl font-serif font-semibold text-slate-900">{children}</h2>
  </div>
);

export default function App() {
  const [currentView, setCurrentView] = useState<'portfolio' | 'profile' | 'avatar'>('portfolio');

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-600 selection:bg-blue-100 selection:text-blue-900">
      {/* Navigation */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="font-serif font-bold text-xl text-slate-900">GLP</div>
          <div className="flex gap-6">
            <button 
              onClick={() => setCurrentView('portfolio')}
              className={`font-medium transition-colors ${currentView === 'portfolio' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
            >
              Portfolio
            </button>
            <button 
              onClick={() => setCurrentView('avatar')}
              className={`font-medium transition-colors flex items-center gap-2 ${currentView === 'avatar' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <Wand2 size={18} /> Avatar
            </button>
            <button 
              onClick={() => setCurrentView('profile')}
              className={`font-medium transition-colors flex items-center gap-2 ${currentView === 'profile' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-900'}`}
            >
              <User size={18} /> Profile
            </button>
          </div>
        </div>
      </nav>

      {currentView === 'portfolio' ? (
        <>
          {/* Header / Hero */}
          <header className="bg-white border-b border-slate-200 pt-16 pb-16 px-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-blue-600"></div>
        <div className="max-w-4xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-4">
              Gerardo Martin Luna Peralta
            </h1>
            <p className="text-xl text-blue-600 font-medium mb-8">
              Medical Intern & Researcher
            </p>
            
            <div className="flex flex-wrap gap-4 mb-8 text-sm">
              <a href="tel:+51998895016" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <Phone size={16} />
                +51 998 895 016
              </a>
              <a href="mailto:gerardo.luna@unmsm.edu.pe" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <Mail size={16} />
                gerardo.luna@unmsm.edu.pe
              </a>
              <a href="mailto:gerardoper97@gmail.com" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <Mail size={16} />
                gerardoper97@gmail.com
              </a>
              <a href="https://orcid.org/0000-0002-3705-5879" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <Globe size={16} />
                ORCID: 0000-0002-3705-5879
              </a>
            </div>

            <div className="flex flex-wrap gap-4 mb-8 text-sm">
              <a href="https://www.linkedin.com/in/gerardo-luna-peralta/" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                LinkedIn
              </a>
              <a href="https://github.com/gerardolunap" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4"></path><path d="M9 18c-4.51 2-5-2-7-2"></path></svg>
                GitHub
              </a>
              <a href="https://x.com/gerarlunap" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
                X (Twitter)
              </a>
              <a href="https://www.tiktok.com/@gerarlunap" target="_blank" rel="noreferrer" className="flex items-center gap-2 text-slate-600 hover:text-blue-600 transition-colors bg-slate-100 px-3 py-1.5 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5"></path></svg>
                TikTok
              </a>
            </div>

            <div className="prose prose-slate max-w-none">
              <p className="text-lg leading-relaxed mb-4">
                7th year medical student at Universidad Nacional Mayor de San Marcos and medical intern at Hospital Nacional Alberto Sabogal Sologuren (ESSALUD) in Callao, Lima. I am also the Past-President (2025) of the Scientific Society of San Fernando (SCSF). I am currently developing primary and secondary research work in the areas of vascular neurology, neuroimmunology and medical education.
              </p>
              <p className="text-lg leading-relaxed">
                Orphaned at the age of 10 and self-raised, my journey has been defined by resilience and a deep search for truth. Navigating the lasting impacts of childhood trauma and PTSD, I have openly grappled with marijuana addiction as a coping mechanism. As an atheist, I view 'god' as a rhetorical word, finding my grounding instead in science, humanism, and the philosophical embrace of uncertainty. I have conceptualized "the eternal present" as my own theory of everything, a framework for understanding existence and time. My life project is oriented to contribute from science and the practice of medicine to the progress of society, especially in reducing socioeconomic gaps, driven by my own lived experiences with vulnerability and healing.
              </p>
            </div>
          </motion.div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-16 space-y-24">
        {/* Featured Story */}
        <section>
          <div className="bg-blue-600 rounded-3xl p-8 md:p-12 text-white shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-50 translate-x-1/2 -translate-y-1/2"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-700 rounded-full mix-blend-multiply filter blur-3xl opacity-50 -translate-x-1/2 translate-y-1/2"></div>
            
            <div className="relative z-10">
              <span className="inline-block px-3 py-1 bg-blue-500/30 border border-blue-400/30 rounded-full text-sm font-medium tracking-wide mb-6">
                Featured Article
              </span>
              <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6 leading-tight">
                The Importance of Free Education In Medicine: My Story
              </h2>
              <div className="text-blue-50 text-lg leading-relaxed max-w-3xl mb-8 space-y-4 opacity-90">
                <p>
                  "I was born in Lima, Perú... When I started medical school at 18, I had already experienced a lot in life: I was an orphan since I was 10 years old... I continue working towards my main academic goals in life: becoming a physician, a teacher, and a scientist."
                </p>
                <p>
                  "All these academic goals head towards my main lifetime goal so far: mitigating socioeconomic barriers in medicine, especially in access to medical education. It has a tremendous impact on the care that the public health system gives to the people and I, as a recipient of public education opportunities, feel very strongly about giving back..."
                </p>
              </div>
              <a 
                href="https://www.neurology.org/media/blog-post/importance-free-education-medicine-my-story"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-white text-blue-600 px-6 py-3 rounded-full font-medium hover:bg-blue-50 transition-colors shadow-sm"
              >
                Read Full Story on Neurology Journals <ExternalLink size={18} />
              </a>
            </div>
          </div>
        </section>

        {/* Education */}
        <section>
          <SectionHeading icon={GraduationCap}>Education</SectionHeading>
          <div className="bg-white rounded-2xl p-6 md:p-8 shadow-sm border border-slate-100">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">National University of San Marcos (UNMSM)</h3>
                <p className="text-slate-500">Lima, PE</p>
              </div>
              <div className="text-left md:text-right">
                <p className="font-medium text-blue-600">Medical student</p>
                <p className="text-sm text-slate-500 flex items-center gap-1 md:justify-end mt-1">
                  <Calendar size={14} />
                  March 2019 – present
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Clinical Experience */}
        <section>
          <SectionHeading icon={Stethoscope}>Clinical Experience</SectionHeading>
          <div className="space-y-6">
            {EXPERIENCE.map((exp, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 md:p-8 shadow-sm border border-slate-100">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-slate-900">{exp.institution}</h3>
                    <p className="text-slate-500 flex items-center gap-1 mt-1">
                      <MapPin size={14} />
                      {exp.location}
                    </p>
                  </div>
                  <div className="text-left md:text-right">
                    <p className="font-medium text-blue-600">{exp.title}</p>
                    <p className="text-sm text-slate-500 flex items-center gap-1 md:justify-end mt-1">
                      <Calendar size={14} />
                      {exp.date}
                    </p>
                  </div>
                </div>
                <p className="text-slate-600 mt-4">{exp.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Awards */}
        <section>
          <SectionHeading icon={Award}>Awards & Recognitions</SectionHeading>
          <div className="space-y-6">
            {AWARDS.map((award, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-3">
                  <h3 className="text-lg font-semibold text-slate-900">{award.title}</h3>
                  <span className="inline-flex items-center gap-1 text-sm font-medium text-blue-600 bg-blue-50 px-3 py-1 rounded-full whitespace-nowrap">
                    <Calendar size={14} />
                    {award.date}
                  </span>
                </div>
                <p className="text-slate-600 leading-relaxed">{award.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Projects */}
        <section>
          <SectionHeading icon={Folder}>Projects</SectionHeading>
          <div className="grid md:grid-cols-2 gap-6">
            {PROJECTS.map((project, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col h-full">
                <h3 className="text-lg font-semibold text-slate-900 mb-3">{project.title}</h3>
                <p className="text-slate-600 leading-relaxed flex-1 mb-6">{project.description}</p>
                {project.link && (
                  <a 
                    href={project.link} 
                    target="_blank" 
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 text-blue-600 font-medium hover:text-blue-700 transition-colors self-start"
                  >
                    {project.linkText || "View Project"} <ExternalLink size={16} />
                  </a>
                )}
              </div>
            ))}
          </div>
        </section>

        {/* Publications */}
        <section>
          <SectionHeading icon={BookOpen}>Publications & Presentations</SectionHeading>
          
          <div className="space-y-12">
            {/* Papers */}
            <div>
              <h3 className="text-xl font-serif font-medium text-slate-900 mb-6 flex items-center gap-2">
                <FileText size={20} className="text-slate-400" />
                Papers
              </h3>
              <div className="space-y-4">
                {PUBLICATIONS.find(p => p.type === 'Papers')?.items.map((item, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <p className="text-slate-700 leading-relaxed">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Posters */}
            <div>
              <h3 className="text-xl font-serif font-medium text-slate-900 mb-6 flex items-center gap-2">
                <FileText size={20} className="text-slate-400" />
                Poster Presentations
              </h3>
              <div className="space-y-6">
                {POSTERS.map((poster, i) => (
                  <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <h4 className="font-semibold text-slate-900">{poster.event}</h4>
                      <span className="text-sm text-slate-500 whitespace-nowrap bg-slate-50 px-3 py-1 rounded-full">{poster.date}</span>
                    </div>
                    {Array.isArray(poster.details) ? (
                      <ul className="space-y-3">
                        {poster.details.map((detail, j) => (
                          <li key={j} className="flex gap-3 text-slate-600">
                            <span className="text-blue-400 mt-1.5 flex-shrink-0">•</span>
                            <span className="leading-relaxed">{detail}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-slate-600 leading-relaxed flex gap-3">
                        <span className="text-blue-400 mt-1.5 flex-shrink-0">•</span>
                        <span>{poster.details}</span>
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Other Publications */}
            {PUBLICATIONS.filter(p => p.type !== 'Papers').map((pubGroup, i) => (
              <div key={i}>
                <h3 className="text-xl font-serif font-medium text-slate-900 mb-6 flex items-center gap-2">
                  <FileText size={20} className="text-slate-400" />
                  {pubGroup.type}
                </h3>
                <div className="grid gap-4">
                  {pubGroup.items.map((item, j) => (
                    <div key={j} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 group">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        <div className="flex-1">
                          <p className="text-slate-700 leading-relaxed font-medium">{item.text}</p>
                          {/* @ts-ignore */}
                          {item.description && <p className="text-slate-500 mt-2 text-sm leading-relaxed">{item.description}</p>}
                        </div>
                        {item.date && <span className="text-sm text-slate-500 whitespace-nowrap bg-slate-50 px-3 py-1 rounded-full">{item.date}</span>}
                      </div>
                      {item.link && (
                        <a 
                          href={item.link} 
                          target="_blank" 
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 text-sm font-medium text-blue-600 mt-4 hover:text-blue-700"
                        >
                          View Resource <ExternalLink size={14} />
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Leadership */}
        <section>
          <SectionHeading icon={Users}>Experience in Leadership</SectionHeading>
          <div className="grid gap-6">
            {LEADERSHIP.map((org, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">{org.organization}</h3>
                <div className="space-y-4">
                  {org.roles.map((role, j) => (
                    <div key={j} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pl-4 border-l-2 border-slate-100">
                      <span className="text-slate-700 font-medium">{role.title}</span>
                      <span className="text-sm text-slate-500 bg-slate-50 px-2 py-1 rounded">{role.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Volunteering */}
        <section>
          <SectionHeading icon={Heart}>Volunteering</SectionHeading>
          <div className="grid gap-4">
            {VOLUNTEERING.map((vol, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h3 className="font-medium text-slate-900 mb-1">{vol.role}</h3>
                  <p className="text-sm text-slate-500 flex items-center gap-1">
                    <MapPin size={14} />
                    {vol.location}
                  </p>
                </div>
                <span className="text-sm font-medium text-slate-500 whitespace-nowrap bg-slate-50 px-3 py-1.5 rounded-full">
                  {vol.date}
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Courses & Skills */}
        <div className="grid md:grid-cols-2 gap-12">
          <section>
            <SectionHeading icon={BookOpen}>Courses</SectionHeading>
            <ul className="space-y-4">
              {COURSES.map((course, i) => (
                <li key={i} className="flex items-start gap-3">
                  <ChevronRight size={18} className="text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-slate-700 font-medium leading-snug">{course.title}</p>
                    <p className="text-sm text-slate-500 mt-1">{course.date}</p>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <SectionHeading icon={Code}>Skills & Languages</SectionHeading>
            <div className="space-y-8">
              <div>
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Technical Skills</h3>
                <div className="space-y-3">
                  {SKILLS.map((skill, i) => (
                    <div key={i}>
                      <span className="font-medium text-slate-700">{skill.category}:</span>{' '}
                      <span className="text-slate-600">{skill.items}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Languages</h3>
                <div className="space-y-3">
                  {LANGUAGES.map((lang, i) => (
                    <div key={i} className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-100">
                      <span className="font-medium text-slate-700">{lang.language}</span>
                      <span className="text-sm text-slate-500">{lang.proficiency}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Contact Form */}
        <section>
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-sm border border-slate-100 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-50 rounded-full mix-blend-multiply filter blur-3xl opacity-50 translate-x-1/2 -translate-y-1/2"></div>
            <div className="relative z-10">
              <SectionHeading icon={Send}>Get in Touch</SectionHeading>
              <p className="text-slate-600 mb-8 max-w-2xl text-lg">
                Whether you want to discuss research, medical education, or just say hi, I'd love to hear from you.
              </p>
              <form className="space-y-6 max-w-2xl" onSubmit={(e) => { e.preventDefault(); alert('Message sent successfully!'); }}>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Name</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white" 
                      placeholder="Your name" 
                      required 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white" 
                      placeholder="your@email.com" 
                      required 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Message</label>
                  <textarea 
                    rows={4} 
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white resize-none" 
                    placeholder="Your message here..." 
                    required
                  ></textarea>
                </div>
                <button 
                  type="submit" 
                  className="flex items-center gap-2 bg-blue-600 text-white px-8 py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors"
                >
                  <Send size={18} />
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>
      </>
      ) : currentView === 'profile' ? (
        <UserProfile />
      ) : (
        <AvatarCreator />
      )}

      <footer className="bg-slate-900 text-slate-400 py-12 text-center">
        <p>© {new Date().getFullYear()} Gerardo Martin Luna Peralta. All rights reserved.</p>
      </footer>
    </div>
  );
}
