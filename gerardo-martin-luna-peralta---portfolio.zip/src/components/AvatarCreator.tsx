import React, { useState, useRef } from 'react';
import { Save, Check, Wand2 } from 'lucide-react';

export default function AvatarCreator() {
  const [skinTone, setSkinTone] = useState('#fcd5ce');
  const [hairStyle, setHairStyle] = useState('short');
  const [hairColor, setHairColor] = useState('#4a4e69');
  const [outfit, setOutfit] = useState('scrubs-blue');
  const [accessory, setAccessory] = useState('stethoscope');
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);

  const skinTones = ['#f8edeb', '#fcd5ce', '#e8a598', '#d4a373', '#a68a64', '#7f5539', '#4b2e1e'];
  const hairColors = ['#2b2d42', '#4a4e69', '#9a8c98', '#c9ada7', '#f2e9e4', '#e07a5f', '#f4a261', '#e9c46a'];
  const hairStyles = ['short', 'long', 'spiky', 'bald'];
  const outfits = [
    { id: 'scrubs-blue', label: 'Blue Scrubs' },
    { id: 'scrubs-green', label: 'Green Scrubs' },
    { id: 'lab-coat', label: 'Lab Coat' }
  ];
  const accessories = [
    { id: 'none', label: 'None' },
    { id: 'glasses', label: 'Glasses' },
    { id: 'stethoscope', label: 'Stethoscope' },
    { id: 'both', label: 'Both' }
  ];

  const saveToProfile = async () => {
    if (!svgRef.current) return;
    setIsSaving(true);
    try {
      const svgString = new XMLSerializer().serializeToString(svgRef.current);
      const base64 = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgString)));
      
      const res = await fetch('/api/profile');
      const profile = await res.json();
      
      await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: profile.username || 'Guest', avatar: base64 })
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e) {
      console.error(e);
    }
    setIsSaving(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12">
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-100">
        <h2 className="text-2xl font-serif font-bold text-slate-900 mb-8 flex items-center gap-2">
          <Wand2 className="text-blue-600" /> Medical Avatar Creator
        </h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          {/* Avatar Preview */}
          <div className="flex flex-col items-center gap-6">
            <div className="w-64 h-64 rounded-3xl overflow-hidden shadow-inner border-4 border-slate-50 bg-slate-100">
              <svg viewBox="0 0 100 100" className="w-full h-full" ref={svgRef} xmlns="http://www.w3.org/2000/svg">
                <rect width="100" height="100" fill="#f8fafc" />
                
                {/* Back Hair (for long hair) */}
                {hairStyle === 'long' && (
                  <path d="M 25 30 L 20 80 Q 50 90 80 80 L 75 30 Z" fill={hairColor} />
                )}

                {/* Body / Outfit */}
                <path d="M 20 100 Q 50 60 80 100 Z" fill={outfit === 'scrubs-blue' ? '#0284c7' : outfit === 'scrubs-green' ? '#059669' : '#ffffff'} stroke={outfit === 'lab-coat' ? '#cbd5e1' : 'none'} strokeWidth="2" />
                
                {/* Lab Coat Details */}
                {outfit === 'lab-coat' && (
                  <>
                    <path d="M 40 100 L 50 75 L 60 100" fill="#f8fafc" stroke="#cbd5e1" strokeWidth="2" />
                    <path d="M 35 100 L 45 65 L 50 75 L 55 65 L 65 100" fill="none" stroke="#cbd5e1" strokeWidth="2" />
                  </>
                )}

                {/* Neck */}
                <rect x="42" y="55" width="16" height="15" fill={skinTone} />
                <path d="M 42 65 Q 50 75 58 65 Z" fill="rgba(0,0,0,0.1)" />

                {/* Head */}
                <circle cx="50" cy="40" r="22" fill={skinTone} />

                {/* Face Details */}
                <circle cx="41" cy="38" r="2.5" fill="#334155" />
                <circle cx="59" cy="38" r="2.5" fill="#334155" />
                <path d="M 44 48 Q 50 54 56 48" fill="none" stroke="#334155" strokeWidth="2" strokeLinecap="round" />

                {/* Front Hair */}
                {hairStyle === 'short' && (
                  <>
                    <path d="M 26 35 Q 50 10 74 35 Q 80 15 50 12 Q 20 15 26 35 Z" fill={hairColor} />
                    <circle cx="50" cy="18" r="14" fill={hairColor} />
                    <circle cx="35" cy="24" r="10" fill={hairColor} />
                    <circle cx="65" cy="24" r="10" fill={hairColor} />
                  </>
                )}
                {hairStyle === 'long' && (
                  <>
                    <circle cx="50" cy="18" r="14" fill={hairColor} />
                    <circle cx="35" cy="24" r="10" fill={hairColor} />
                    <circle cx="65" cy="24" r="10" fill={hairColor} />
                  </>
                )}
                {hairStyle === 'spiky' && (
                  <polygon points="26,35 30,15 40,25 50,10 60,25 70,15 74,35" fill={hairColor} />
                )}

                {/* Accessories */}
                {(accessory === 'glasses' || accessory === 'both') && (
                  <g stroke="#334155" strokeWidth="2" fill="none">
                    <rect x="32" y="33" width="14" height="10" rx="2" />
                    <rect x="54" y="33" width="14" height="10" rx="2" />
                    <line x1="46" y1="38" x2="54" y2="38" />
                    <line x1="28" y1="38" x2="32" y2="38" />
                    <line x1="68" y1="38" x2="72" y2="38" />
                  </g>
                )}
                {(accessory === 'stethoscope' || accessory === 'both') && (
                  <g>
                    <path d="M 32 65 Q 50 100 68 65" fill="none" stroke="#334155" strokeWidth="3" />
                    <path d="M 68 65 L 75 80" fill="none" stroke="#334155" strokeWidth="3" />
                    <circle cx="75" cy="80" r="4" fill="#64748b" />
                    <circle cx="75" cy="80" r="2" fill="#94a3b8" />
                  </g>
                )}
              </svg>
            </div>
            
            <button 
              onClick={saveToProfile}
              disabled={isSaving || saved}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-colors w-full justify-center ${
                saved 
                  ? 'bg-emerald-100 text-emerald-700' 
                  : 'bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-70'
              }`}
            >
              {saved ? <><Check size={20} /> Saved to Profile!</> : <><Save size={20} /> {isSaving ? 'Saving...' : 'Set as Profile Picture'}</>}
            </button>
          </div>

          {/* Controls */}
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Skin Tone</label>
              <div className="flex flex-wrap gap-2">
                {skinTones.map(color => (
                  <button
                    key={color}
                    onClick={() => setSkinTone(color)}
                    className={`w-10 h-10 rounded-full border-2 transition-transform ${skinTone === color ? 'border-blue-500 scale-110' : 'border-transparent hover:scale-105'}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Hair Style</label>
              <div className="flex flex-wrap gap-2">
                {hairStyles.map(style => (
                  <button
                    key={style}
                    onClick={() => setHairStyle(style)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-colors ${hairStyle === style ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>

            {hairStyle !== 'bald' && (
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">Hair Color</label>
                <div className="flex flex-wrap gap-2">
                  {hairColors.map(color => (
                    <button
                      key={color}
                      onClick={() => setHairColor(color)}
                      className={`w-8 h-8 rounded-full border-2 transition-transform ${hairColor === color ? 'border-blue-500 scale-110' : 'border-transparent hover:scale-105'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Outfit</label>
              <div className="flex flex-wrap gap-2">
                {outfits.map(o => (
                  <button
                    key={o.id}
                    onClick={() => setOutfit(o.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${outfit === o.id ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Accessories</label>
              <div className="flex flex-wrap gap-2">
                {accessories.map(a => (
                  <button
                    key={a.id}
                    onClick={() => setAccessory(a.id)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${accessory === a.id ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    {a.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
