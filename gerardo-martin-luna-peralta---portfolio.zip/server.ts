import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Setup SQLite
  const db = new Database('app.db');
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT,
      avatar TEXT
    );
    CREATE TABLE IF NOT EXISTS activities (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (userCount.count === 0) {
    db.prepare('INSERT INTO users (username, avatar) VALUES (?, ?)').run('Guest', '');
  }

  // API Routes
  app.get("/api/profile", (req, res) => {
    const user = db.prepare('SELECT * FROM users ORDER BY id ASC LIMIT 1').get();
    res.json(user);
  });

  app.post("/api/profile", (req, res) => {
    const { username, avatar } = req.body;
    const user = db.prepare('SELECT id FROM users ORDER BY id ASC LIMIT 1').get() as { id: number };
    
    db.prepare('UPDATE users SET username = ?, avatar = ? WHERE id = ?').run(username, avatar, user.id);
    db.prepare('INSERT INTO activities (user_id, action) VALUES (?, ?)').run(user.id, `Updated profile to username: ${username}`);
    
    res.json({ success: true });
  });

  app.get("/api/activity", (req, res) => {
    const user = db.prepare('SELECT id FROM users ORDER BY id ASC LIMIT 1').get() as { id: number };
    const activities = db.prepare('SELECT * FROM activities WHERE user_id = ? ORDER BY created_at DESC').all(user.id);
    res.json(activities);
  });

  app.post("/api/activity", (req, res) => {
    const { action } = req.body;
    const user = db.prepare('SELECT id FROM users ORDER BY id ASC LIMIT 1').get() as { id: number };
    db.prepare('INSERT INTO activities (user_id, action) VALUES (?, ?)').run(user.id, action);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
